#Cargar una lista con números. Invertir los elementos sin usar otra lista. 
lista_numeros = []

for i in range(5):
    numeros = int(input('Ingrese un numero: '))
    lista_numeros.append(numeros)


lista_numeros.sort(reverse=True) 
print (lista_numeros) 

















