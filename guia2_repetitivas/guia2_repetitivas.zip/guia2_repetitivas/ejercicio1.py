#Mostrar por pantalla los primeros 5 números naturales.

for vr in range (1,6):
    print(vr)
















