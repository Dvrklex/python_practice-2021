#Mostrar los primeros 35 múltiplos de 5.

n = 5
for i in range (n,n*36,5):
    print(i)




