palabras = 'lapicera cuaderno tetera barco aguja tijera esmalte piedra cerdo cebra cepillo sierra carro tinta cinta peine gancho cierre valija cuerda radio televisor mueble soldado plato jarra tigre suelo viento lluvia fuego abanico abastecimiento abeja abstinencia abuela abundancia caudillo director harina trigo bandeja calentador disco manta sombrero gorra remera chomba camisa pollera calzoncillo puerta ventana vereda silla velador monitor teclado pantalla madera hierro acero vidrio zapato manada canguro dinosaurio esquina raqueta receta arena pared planta animal '
listadoPalabras = palabras.split()

numero = int(input('Ingrese un numero del 0 - 50: '))




