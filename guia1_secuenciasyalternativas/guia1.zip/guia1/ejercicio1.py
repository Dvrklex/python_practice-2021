#Pedir dos números enteros, sumarlos y mostrar el resultado.
primer_numero_entero = input('Ingrese el primer número: \r\n')
primer_numero_entero = int(primer_numero_entero)
segundo_numero_entero= input('Ingrese el segundo número: \r\n')
segundo_numero_entero = int(segundo_numero_entero)
resultado = primer_numero_entero + segundo_numero_entero
print('El resultado es', primer_numero_entero + segundo_numero_entero )