#Pedir tres notas, calcular el promedio y mostrarlo.
primera_nota = input('Ingrese la primera nota: \r\n')
primera_nota = float(primera_nota)
segunda_nota = input('Ingrese la segunda nota: \r\n')
segunda_nota = float(segunda_nota)
tercer_nota = input('Ingrese tecer nota: \r\n')
tercer_nota = float(tercer_nota)

suma_de_tres_notas = (primera_nota + segunda_nota + tercer_nota) / 3

print(suma_de_tres_notas)





